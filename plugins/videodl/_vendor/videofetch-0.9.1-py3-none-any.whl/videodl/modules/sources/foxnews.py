'''
Function:
    Implementation of FoxNewsVideoClient
Author:
    Zhenchao Jin
WeChat Official Account (微信公众号):
    Charles的皮卡丘
'''
import os
import re
from .base import BaseVideoClient
from ..utils import legalizestring, useparseheaderscookies, resp2json, searchdictbykey, yieldtimerelatedtitle, safeextractfromdict, FileTypeSniffer, VideoInfo


'''FoxNewsVideoClient'''
class FoxNewsVideoClient(BaseVideoClient):
    source = 'FoxNewsVideoClient'
    def __init__(self, **kwargs):
        super(FoxNewsVideoClient, self).__init__(**kwargs)
        self.default_parse_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'}
        self.default_download_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'}
        self.default_headers = self.default_parse_headers
        self._initsession()
    '''parsefromurl'''
    @useparseheaderscookies
    def parsefromurl(self, url: str, request_overrides: dict = None):
        # prepare
        if not self.belongto(url=url): return []
        request_overrides, video_info, null_backup_title = request_overrides or {}, VideoInfo(source=self.source, enable_nm3u8dlre=True), yieldtimerelatedtitle(self.source)
        # try parse
        try:
            re_patterns = [r'https?://(?:www\.)?foxnews\.com/video/(?P<id>\d+)', r'https?://video\.(?:insider\.)?fox(?:news|business)\.com/v/(?:video-embed\.html\?video_id=)?(?P<id>\d+)']
            video_id = next((m.group('id') for p in re_patterns if (m := re.match(p, url)) and 'id' in m.groupdict()), None)
            (resp := self.get(f'https://api.foxnews.com/v3/video-player/{video_id}?callback=uid_{video_id}', **request_overrides)).raise_for_status()
            video_info.update(dict(raw_data=(raw_data := resp2json(resp=resp))))
            download_url = searchdictbykey(raw_data, 'media-content')[0][0]['@attributes']['url']
            video_info.update(dict(download_url=download_url)); video_title = searchdictbykey(raw_data, 'media-title')
            video_title = legalizestring(video_title[0] if video_title else null_backup_title, replace_null_string=null_backup_title).removesuffix('.')
            guess_video_ext_result = FileTypeSniffer.getfileextensionfromurl(url=download_url, headers=self.default_download_headers, request_overrides=request_overrides, cookies=self.default_download_cookies)
            ext = guess_video_ext_result['ext'] if guess_video_ext_result['ext'] and guess_video_ext_result['ext'] != 'NULL' else video_info.ext
            cover_url = safeextractfromdict(raw_data, ['channel', 'item', 'media-group', 'media-thumbnail', '@attributes', 'url'], None)
            video_info.update(dict(title=video_title, save_path=os.path.join(self.work_dir, self.source, f'{video_title}.{ext}'), ext=ext, guess_video_ext_result=guess_video_ext_result, identifier=video_id, cover_url=cover_url))
        except Exception as err:
            video_info.update(dict(err_msg=(err_msg := f'{self.source}.parsefromurl >>> {url} (Error: {err})')))
            self.logger_handle.error(err_msg, disable_print=self.disable_print)
        # return
        return [video_info]
    '''belongto'''
    @staticmethod
    def belongto(url: str, valid_domains: list[str] | set[str] = None):
        valid_domains = set(valid_domains or []) | {"foxnews.com"}
        return BaseVideoClient.belongto(url, valid_domains)