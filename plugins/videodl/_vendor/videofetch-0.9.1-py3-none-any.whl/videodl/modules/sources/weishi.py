'''
Function:
    Implementation of WeishiVideoClient
Author:
    Zhenchao Jin
WeChat Official Account (微信公众号):
    Charles的皮卡丘
'''
import os
import re
import json_repair
from bs4 import BeautifulSoup
from .base import BaseVideoClient
from urllib.parse import parse_qs, urlparse
from ..utils import legalizestring, useparseheaderscookies, yieldtimerelatedtitle, safeextractfromdict, FileTypeSniffer, VideoInfo


'''WeishiVideoClient'''
class WeishiVideoClient(BaseVideoClient):
    source = 'WeishiVideoClient'
    def __init__(self, **kwargs):
        super(WeishiVideoClient, self).__init__(**kwargs)
        self.default_parse_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'}
        self.default_download_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36'}
        self.default_headers = self.default_parse_headers
        self._initsession()
    '''parsefromurl'''
    @useparseheaderscookies
    def parsefromurl(self, url: str, request_overrides: dict = None) -> list[VideoInfo]:
        # prepare
        if not self.belongto(url=url): return []
        request_overrides, video_info, null_backup_title = request_overrides or {}, VideoInfo(source=self.source), yieldtimerelatedtitle(self.source)
        quality_score_func = lambda spec: (spec.get("videoQuality") or 0, (spec.get("width") or 0) * (spec.get("height") or 0), spec.get("fps") or 0, int(spec.get("size") or 0))
        # try parse
        try:
            if 'id' in parse_qs(urlparse(url).query, keep_blank_values=True): vid = parse_qs(urlparse(url).query, keep_blank_values=True)['id'][0]
            else: vid = urlparse(url).path.strip('/').split('/')[-1]
            (resp := self.get(url, **request_overrides)).raise_for_status()
            soup = BeautifulSoup(resp.text, "html.parser"); script_tag = soup.find("script", string=re.compile(r"window\.Vise\.initState"))
            m = re.search(r"window\.Vise\.initState\s*=\s*({.*?});", script_tag.string or script_tag.get_text(), re.S)
            video_info.update(dict(raw_data=(raw_data := json_repair.loads(m.group(1)))))
            video_spec_urls: dict = raw_data["feedsList"][0]["videoSpecUrls"]
            spec_list: list[dict] = list(video_spec_urls.values()); spec_list = [s for s in spec_list if s.get('url')]
            spec_list_sorted: list[dict] = sorted(spec_list, key=quality_score_func, reverse=True)
            spec_list_sorted: list[dict] = [item for item in spec_list_sorted if item.get('url')]
            video_info.update(dict(download_url=(download_url := spec_list_sorted[0]['url'] if len(spec_list_sorted) > 0 else raw_data["feedsList"][0]['videoUrl'])))
            video_title = legalizestring(safeextractfromdict(raw_data, ['feedsList', 0, 'feedDesc'], None) or null_backup_title, replace_null_string=null_backup_title).removesuffix('.')
            guess_video_ext_result = FileTypeSniffer.getfileextensionfromurl(url=download_url, headers=self.default_download_headers, request_overrides=request_overrides, cookies=self.default_download_cookies)
            ext = guess_video_ext_result['ext'] if guess_video_ext_result['ext'] and guess_video_ext_result['ext'] != 'NULL' else video_info.ext
            cover_url = safeextractfromdict(raw_data, ['feedsList', 0, 'images', 0, 'url'], None)
            video_info.update(dict(title=video_title, save_path=os.path.join(self.work_dir, self.source, f'{video_title}.{ext}'), ext=ext, guess_video_ext_result=guess_video_ext_result, identifier=vid, cover_url=cover_url))
        except Exception as err:
            video_info.update(dict(err_msg=(err_msg := f'{self.source}.parsefromurl >>> {url} (Error: {err})')))
            self.logger_handle.error(err_msg, disable_print=self.disable_print)
        # return
        return [video_info]
    '''belongto'''
    @staticmethod
    def belongto(url: str, valid_domains: list[str] | set[str] = None):
        valid_domains = set(valid_domains or []) | {"weishi.qq.com"}
        return BaseVideoClient.belongto(url, valid_domains)