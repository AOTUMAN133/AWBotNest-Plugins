'''
Function:
    Implementation of ODwonVideoClient: https://odown.cc/cctv
Author:
    Zhenchao Jin
WeChat Official Account (微信公众号):
    Charles的皮卡丘
'''
import os
import json
import copy
import base64
from contextlib import suppress
from Cryptodome.Cipher import AES
from Cryptodome.PublicKey import RSA
from ..sources import BaseVideoClient
from Cryptodome.Util.Padding import pad
from Cryptodome.Cipher import PKCS1_v1_5
from ..utils.domains import platformfromurl
from ..utils import RandomIPGenerator, VideoInfo, FileTypeSniffer, useparseheaderscookies, legalizestring, resp2json, yieldtimerelatedtitle, safeextractfromdict


'''ODwonVideoClient'''
class ODwonVideoClient(BaseVideoClient):
    source = 'ODwonVideoClient'
    def __init__(self, **kwargs):
        super(ODwonVideoClient, self).__init__(**kwargs)
        self.default_parse_headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36", "Accept": "application/json", "Content-Type": "application/json", "Origin": "https://odown.cc", "kdsystem": "ChengZi"}
        self.default_download_headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"}
        self.default_headers = self.default_parse_headers
        self._initsession()
    '''parsefromurl'''
    @useparseheaderscookies
    def parsefromurl(self, url: str, request_overrides: dict = None) -> list[VideoInfo]:
        # prepare
        request_overrides, null_backup_title, video_infos = request_overrides or {}, yieldtimerelatedtitle(self.source), []
        video_info = VideoInfo(source=self.source, enable_nm3u8dlre=False, download_with_ffmpeg=True) if BaseVideoClient.belongto(url, {"ted.com", "xinpianchang.com", "ifeng.com"}) else VideoInfo(source=self.source, enable_nm3u8dlre=True)
        if platformfromurl(url) in {'bilibili'}: video_info.update(dict(default_download_headers=self.BILIBILI_REFERENCE_HEADERS, default_audio_download_headers=self.BILIBILI_REFERENCE_HEADERS))
        if platformfromurl(url) in {'weibo'}: video_info.update(dict(default_download_headers=self.WEIBO_REFERENCE_HEADERS, default_audio_download_headers=self.WEIBO_REFERENCE_HEADERS))
        # try parse
        try:
            # --encrypt post data
            json_string = json.dumps({"url": url}, separators=(",", ":"), ensure_ascii=False)
            headers = copy.deepcopy(self.default_headers); RandomIPGenerator().addrandomipv4toheaders(headers)
            (keys_resp := self.get('https://odown.cc/api/auth/keys', headers=headers, **request_overrides)).raise_for_status()
            keys_data = resp2json(resp=keys_resp)["data"]; rsa_public_key = RSA.import_key(base64.b64decode(keys_data["k1"])); k2_bytes = base64.b64decode(keys_data["k2"])
            k2_plain_bytes = pow(int.from_bytes(k2_bytes, "big"), rsa_public_key.e, rsa_public_key.n).to_bytes(rsa_public_key.size_in_bytes(), "big")
            aes_key_bytes = k2_plain_bytes[k2_plain_bytes.find(b"\x00", 2) + 1:]; iv_bytes = b"kedou@8989!63233"; data_bytes = json_string.encode("utf-8")
            aes_cipher = AES.new(aes_key_bytes, AES.MODE_CBC, iv_bytes); aes_encrypted = base64.b64encode(aes_cipher.encrypt(pad(data_bytes, AES.block_size))).decode("utf-8")
            rsa_cipher = PKCS1_v1_5.new(rsa_public_key); rsa_encrypted = base64.b64encode(rsa_cipher.encrypt(aes_encrypted.encode("utf-8"))).decode("utf-8")
            # --post request
            (resp := self.post('https://odown.cc/api/video/cnSimpleExtract', data=rsa_encrypted, headers=headers, **request_overrides)).raise_for_status()
            video_info.update(dict(raw_data=(raw_data := resp2json(resp=resp))))
            if raw_data.get("code") != 200: raise ValueError(raw_data)
            # --sort by quality
            data_items = raw_data["data"]["videoItemVoList"]
            video_items: list[dict] = [x for x in data_items if isinstance(x, dict) and x.get("baseUrl") and str(x["baseUrl"]).startswith('http') and ((x.get('fileType') in {"video"}) or (x.get('quality') not in {'音频', '封面'}))]
            video_items_sorted = sorted(video_items, key=lambda item: item.get("size", 0) or 0, reverse=True)
            audio_items: list[dict] = [x for x in data_items if isinstance(x, dict) and x.get("baseUrl") and str(x["baseUrl"]).startswith('http') and ((x.get('fileType') in {"audio"}) or (x.get('quality') in {'音频'}))]
            audio_items_sorted = sorted(audio_items, key=lambda item: item.get("size", 0) or 0, reverse=True)
            video_info.update(dict(download_url=(download_url := video_items_sorted[0]['baseUrl'])))
            if ((not (audio_download_url := video_items_sorted[0].get('audioUrl'))) or (not str(audio_download_url).startswith('http'))) and audio_items_sorted: audio_download_url = audio_items_sorted[0].get('baseUrl')
            if audio_download_url and str(audio_download_url).startswith('http'): video_info.update(dict(audio_download_url=audio_download_url))
            # --video title
            video_title = legalizestring(safeextractfromdict(raw_data, ['data', 'displayTitle'], None) or null_backup_title, replace_null_string=null_backup_title).removesuffix('.')
            # --other infos
            guess_video_ext_result = FileTypeSniffer.getfileextensionfromurl(url=download_url, headers=self.default_download_headers, request_overrides=request_overrides, cookies=self.default_download_cookies)
            ext = guess_video_ext_result['ext'] if guess_video_ext_result['ext'] and guess_video_ext_result['ext'] != 'NULL' else video_info['ext']
            with suppress(Exception): cover_url = None; cover_url = [x for x in data_items if isinstance(x, dict) and x.get("baseUrl") and str(x["baseUrl"]).startswith('http') and ((x.get('fileType') in {"image"}) or (x.get('quality') in {'封面'}))][0]['baseUrl']
            video_info.update(dict(title=video_title, save_path=os.path.join(self.work_dir, self.source, f'{video_title}.{ext}'), ext=ext, guess_video_ext_result=guess_video_ext_result, identifier=safeextractfromdict(raw_data, ['data', 'vid'], None) or video_title, cover_url=cover_url))
            if audio_download_url and str(audio_download_url).startswith('http'):
                video_info.update(dict(guess_audio_ext_result=(guess_audio_ext_result := FileTypeSniffer.getfileextensionfromurl(url=audio_download_url, headers=self.default_download_headers, request_overrides=request_overrides, cookies=self.default_download_cookies))))
                if (audio_ext := guess_audio_ext_result['ext'] if guess_audio_ext_result['ext'] and guess_audio_ext_result['ext'] != 'NULL' else video_info['audio_ext']) in ['m4s', 'mp4']: audio_ext = 'm4a'
                video_info.update(dict(audio_ext=audio_ext, audio_save_path=os.path.join(self.work_dir, self.source, f'{video_title}.audio.{audio_ext}')))
            video_infos.append(video_info)
        except Exception as err:
            video_info.update(dict(err_msg=(err_msg := f'{self.source}.parsefromurl >>> {url} (Error: {err})'))); video_infos.append(video_info)
            self.logger_handle.error(err_msg, disable_print=self.disable_print)
        # return
        return video_infos